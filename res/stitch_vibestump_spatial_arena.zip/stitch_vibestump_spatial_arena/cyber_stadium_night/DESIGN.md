---
name: Cyber-Stadium Night
colors:
  surface: '#0c1609'
  surface-dim: '#0c1609'
  surface-bright: '#323c2d'
  surface-container-lowest: '#071105'
  surface-container-low: '#141e11'
  surface-container: '#182214'
  surface-container-high: '#222d1e'
  surface-container-highest: '#2d3828'
  on-surface: '#dae6d0'
  on-surface-variant: '#baccb0'
  inverse-surface: '#dae6d0'
  inverse-on-surface: '#293324'
  outline: '#85967c'
  outline-variant: '#3c4b35'
  surface-tint: '#2ae500'
  primary: '#efffe3'
  on-primary: '#053900'
  primary-container: '#39ff14'
  on-primary-container: '#107100'
  inverse-primary: '#106e00'
  secondary: '#d3fbff'
  on-secondary: '#00363a'
  secondary-container: '#00eefc'
  on-secondary-container: '#00686f'
  tertiary: '#fbf9ff'
  on-tertiary: '#2b3040'
  tertiary-container: '#d8ddf1'
  on-tertiary-container: '#5c6172'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#79ff5b'
  primary-fixed-dim: '#2ae500'
  on-primary-fixed: '#022100'
  on-primary-fixed-variant: '#095300'
  secondary-fixed: '#7df4ff'
  secondary-fixed-dim: '#00dbe9'
  on-secondary-fixed: '#002022'
  on-secondary-fixed-variant: '#004f54'
  tertiary-fixed: '#dde2f6'
  tertiary-fixed-dim: '#c1c6da'
  on-tertiary-fixed: '#161b2a'
  on-tertiary-fixed-variant: '#414657'
  background: '#0c1609'
  on-background: '#dae6d0'
  surface-variant: '#2d3828'
  pitch-green: '#39FF14'
  electric-cyan: '#00F0FF'
  deep-obsidian: '#060B19'
  surface-glass: rgba(15, 23, 42, 0.45)
  border-highlight: rgba(255, 255, 255, 0.08)
typography:
  display-xl:
    fontFamily: Space Grotesk
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  metric-lg:
    fontFamily: JetBrains Mono
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.04em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  container-margin: 24px
  gutter: 16px
  card-padding: 20px
  section-gap: 40px
---

## Brand & Style

This design system embodies the high-stakes adrenaline of a night-time cricket final, filtered through a futuristic, spatial computing lens. It is designed for immersive, high-fidelity sports dashboards that prioritize real-time data visualization and "Agentic" intelligence.

The visual style is a hybrid of **Glassmorphism** and **High-Contrast Neon**, drawing heavy inspiration from spatial OS interfaces. It utilizes deep layering, background blurs, and vibrant light-emission to create a UI that feels like a holographic projection within a stadium. The mood is athletic, cinematic, and aggressively tech-forward, moving away from flat "SaaS" aesthetics toward a gaming-inspired, premium experience.

## Colors

The palette is centered around a "Night Stadium" concept. The base is **Deep Space Obsidian**, an ultra-dark navy that provides infinite depth. High-energy accents are reserved for interactive elements and critical data points: **Neon Pitch Green** for success, action, and active play; **Electric Umbra Cyan** for information, headers, and UI glows.

Functional surfaces are not solid; they use a translucent **Surface Glass** to allow the underlying obsidian gradients to peek through. All primary interactive elements and headings should feel like they are emitting light, rather than reflecting it.

## Typography

Typography is split into three functional roles:
1.  **Display & Headers:** Using **Space Grotesk** for its aggressive, geometric architecture. All Level 1 and Level 2 headers should feature a subtle `text-shadow` using the Electric Umbra Cyan color to simulate a neon glow.
2.  **Narrative & Body:** **Inter** provides high legibility for commentary and descriptive text, ensuring the complex dashboard remains readable during fast-paced play.
3.  **Data & Metrics:** **JetBrains Mono** is used for scores, run rates, and temporal data. Its tabular lining ensures that numbers do not "jump" or jitter when updating every 10 seconds.

## Layout & Spacing

The system uses a **Fluid Dashboard Grid** optimized for spatial immersion. 
- **Desktop:** A 12-column layout with 24px margins. Content is organized in modular "Glass Panes" that can span various column widths (e.g., Metrics span 3, Live Feed spans 9).
- **Mobile:** A single-column vertical stack with 16px side margins. 
- **Rhythm:** A 4px baseline grid ensures tight vertical alignment. Large sections are separated by a 40px gap to provide visual breathing room between disparate data modules like "Runs Progression" and "Match Highlights."

## Elevation & Depth

Depth is achieved through **Glassmorphism and Internal Glows** rather than traditional drop shadows.
- **Base Layer:** Deep Space Obsidian background with radial gradients (#111827 at center to #060B19 at edges).
- **Surface Layer:** All cards and panels use `backdrop-filter: blur(24px)` with a 45% opaque dark fill. 
- **Definition:** Instead of outer shadows, use a 1px inner border (`rgba(255, 255, 255, 0.08)`) to catch the light at the edges of the "glass" panels.
- **Active State:** Elements in focus or "Live" play should exhibit an outer `box-shadow` glow using the Pitch Green or Electric Cyan at 20-30% opacity.

## Shapes

The design system uses **Rounded** geometry (8px / 0.5rem base) to soften the technical edge and provide a premium "hardware" feel. 
- **Panels/Cards:** Use `rounded-lg` (16px) to create a soft, friendly container for hard data.
- **Interactive Badges:** Use full pill shapes (rounded-full) for status indicators like "LIVE" or "BAT".
- **Selection States:** Use subtle rounded corners on list item hovers to maintain the spatial consistency.

## Components

### Buttons
Primary buttons use the **Neon Pitch Green** background with black text for maximum contrast. Secondary buttons use a "Ghost" style: a 1px Electric Cyan border and cyan text with a subtle background blur.

### Chips & Badges
"Live" status chips must pulse with a Pitch Green glow. Use JetBrains Mono for the text inside chips to maintain the technical/data-first aesthetic.

### Glass Cards
The primary container for all modules. Must include the `backdrop-filter`, the 1px subtle inner border, and `rounded-lg` corners. Headers inside cards should be uppercase Space Grotesk.

### Inputs & Search
Input fields are "Cutouts" into the glass panels—slightly darker than the card surface with a 1px border that illuminates to Electric Cyan on focus.

### Metrics Display
Scoreboards and run-rates should be the largest elements on the screen. Use **Metric-LG** (JetBrains Mono) with high contrast against the obsidian background to ensure glanceability from a distance.

### VibeStump Branding
The VibeStump logo should be placed in the top-left navigation bar, paired with the "Agentic Premier League" text in Space Grotesk. Ensure the logo has a subtle drop-shadow to lift it off the glass navigation bar.