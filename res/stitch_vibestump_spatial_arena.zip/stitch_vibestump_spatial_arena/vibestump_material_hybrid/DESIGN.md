---
name: VibeStump Material Hybrid
colors:
  surface: '#10131a'
  surface-dim: '#10131a'
  surface-bright: '#363941'
  surface-container-lowest: '#0b0e15'
  surface-container-low: '#191c23'
  surface-container: '#1d2027'
  surface-container-high: '#272a31'
  surface-container-highest: '#32353c'
  on-surface: '#e0e2ec'
  on-surface-variant: '#c1c6d6'
  inverse-surface: '#e0e2ec'
  inverse-on-surface: '#2d3038'
  outline: '#8b909f'
  outline-variant: '#414754'
  surface-tint: '#adc7ff'
  primary: '#adc7ff'
  on-primary: '#002e68'
  primary-container: '#1a73e8'
  on-primary-container: '#ffffff'
  inverse-primary: '#005bc0'
  secondary: '#6ddd81'
  on-secondary: '#003914'
  secondary-container: '#30a550'
  on-secondary-container: '#003210'
  tertiary: '#ffb4a9'
  on-tertiary: '#690002'
  tertiary-container: '#dc392c'
  on-tertiary-container: '#ffffff'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#d8e2ff'
  primary-fixed-dim: '#adc7ff'
  on-primary-fixed: '#001a41'
  on-primary-fixed-variant: '#004493'
  secondary-fixed: '#89fa9b'
  secondary-fixed-dim: '#6ddd81'
  on-secondary-fixed: '#002108'
  on-secondary-fixed-variant: '#005320'
  tertiary-fixed: '#ffdad5'
  tertiary-fixed-dim: '#ffb4a9'
  on-tertiary-fixed: '#410001'
  on-tertiary-fixed-variant: '#930004'
  background: '#10131a'
  on-background: '#e0e2ec'
  surface-variant: '#32353c'
typography:
  display-lg:
    fontFamily: Space Grotesk
    fontSize: 57px
    fontWeight: '700'
    lineHeight: 64px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
  title-lg:
    fontFamily: Space Grotesk
    fontSize: 22px
    fontWeight: '500'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.1px
  data-mono:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: -0.01em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 32px
  container-max-width: 1280px
---

## Brand & Style

The design system is a sophisticated evolution of Material 3 principles, optimized for high-performance data environments and creative expression. It bridges the gap between structured enterprise utility and forward-thinking aesthetics by merging Google’s iconic color theory with a technical, glassmorphic UI layer.

The personality is **innovative, systematic, and vibrant**. It targets a user base that demands the reliability of a mature design language but seeks a visual edge that feels contemporary and "tech-native." The UI evokes an emotional response of clarity and precision, using transparency and blur to create a sense of digital lightness while maintaining a rigorous information hierarchy.

## Colors

The color palette is rooted in the four-color Google heritage, providing immediate brand recognition. For the default **Dark Mode**, these colors transition into high-accessibility pastel variants that reduce ocular strain while maintaining their semantic meaning.

- **Primary (Blue):** Used for key actions, selection states, and brand presence.
- **Secondary (Green):** Indicates success, growth, and secondary utility actions.
- **Tertiary (Red):** Reserved for destructive actions, errors, and urgent notifications.
- **Quaternary (Yellow):** Applied for warnings, highlights, and attention-grabbing accents.

Surface colors in dark mode utilize a deep charcoal base rather than pure black to allow for the glassmorphic backdrop blurs and subtle "inner-glow" strokes to remain visible.

## Typography

This design system employs a dual-font strategy to balance character with utility. 

**Space Grotesk** is used for all "Display," "Headline," and "Title" roles. Its geometric quirks and technical personality align with the glassmorphic aesthetic, providing a bold, futurist tone to the interface.

**Inter** is the workhorse for all "Body," "Label," and "Data" roles. Its neutral, high-legibility structure ensures that complex information and dense data sets remain readable at all sizes. Use `data-mono` (Inter with tighter tracking) for numerical displays and code-adjacent snippets to ensure alignment and clarity.

## Layout & Spacing

The layout is built on a **12-column fluid grid** for desktop, collapsing to **4 columns** on mobile devices. All spacing follows a strict **8px rhythm**, ensuring vertical and horizontal alignment across all components.

- **Desktop (1240px+):** 12 columns, 24px gutters, 32px side margins.
- **Tablet (600px - 1239px):** 8 columns, 16px gutters, 24px side margins.
- **Mobile (0px - 599px):** 4 columns, 16px gutters, 16px side margins.

Content is organized into "Surfaces" that can span multiple columns. Use padding increments of 8px (e.g., 16, 24, 32) to maintain consistent internal breathing room within glassmorphic containers.

## Elevation & Depth

Hierarchy is established through a combination of **Glassmorphism** and **Tonal Layering**. Unlike traditional Material 3 which uses heavy drop shadows, this design system utilizes:

1.  **Backdrop Blurs:** Surfaces use a `20px` to `40px` blur radius to separate foreground content from background noise.
2.  **Translucency:** Background colors are applied at `60%` to `80%` opacity to allow colors to bleed through subtly.
3.  **Sharp Edge Definitions:** Every elevated surface features a `1px` semi-transparent inner border (stroke). On the top and left, the stroke is slightly brighter (simulating a light source); on the bottom and right, it is slightly darker.
4.  **Tinted Overlays:** Higher elevation levels are indicated by lighter background opacities rather than darker shadows, creating a "lifting" effect.

## Shapes

The shape language is **Rounded (Level 2)**, which provides a friendly, approachable feel that offsets the technicality of the typography and glass effects.

- **Small Components (Buttons, Chips, Inputs):** 8px (`0.5rem`) corner radius.
- **Medium Components (Cards, Modals, Menus):** 16px (`1rem`) corner radius.
- **Large Components (Main Containers, Sheets):** 24px (`1.5rem`) corner radius.

The "Sharp Edge Definition" mentioned in the elevation section is applied via a crisp 1px stroke that follows these rounded corners perfectly, ensuring the interface feels structural rather than "mushy."

## Components

### Buttons
- **Primary:** Solid color (Google Blue or pastel variant) with high-contrast text. No blur.
- **Secondary (Glass):** Semi-transparent background with a 1px border. Backdrop blur applied.
- **Tertiary:** Text-only with an 8px radius hover state.

### Input Fields
Inputs use a "Filled" style with a glassmorphic twist. The container has a 10% white/black opacity with a bottom-heavy 2px border that glows when focused. Labels use Inter 12px Medium.

### Cards
Cards are the primary vehicle for glassmorphism. They must always include:
- `backdrop-filter: blur(24px)`
- `background: rgba(var(--surface-color), 0.7)`
- `border: 1px solid rgba(255, 255, 255, 0.1)`

### Chips & Tags
Small, highly rounded (pill-shaped) elements. Use the pastel color variants for background tints and the primary colors for text to ensure maximum readability against blurred backgrounds.

### Lists
List items are separated by subtle 1px dividers. Hover states should use a "glass-lifting" effect, where the background opacity increases by 10% and the inner stroke becomes more pronounced.